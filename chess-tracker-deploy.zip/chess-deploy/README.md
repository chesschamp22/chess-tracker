# Chess Rating Tracker — Local Server Setup

## Quick Start

```bash
pip install requests
python3 server.py
```

Then open **http://localhost:8765** in your browser.

---

## What the server does

| Endpoint | Purpose |
|---|---|
| `GET /` | Serves chess-tracker.html |
| `GET /uscf/members/<id>` | Proxies USCF ratings API (bypasses CORS) |
| `POST /chesskid` | Logs into ChessKid, returns real stats + history |

---

## ChessKid Setup

1. In the app, edit a profile
2. Enter the **ChessKid username**
3. Enter the **ChessKid password** (stored only in your browser's localStorage)
4. Save — the app will POST credentials to your local server, log in, and fetch full rating history including puzzles

**Your password never leaves your computer** — it goes from your browser → localhost:8765 → chesskid.com only.

---

## Deploy to Render (free)

1. Push this folder to a GitHub repo
2. Go to render.com → New Web Service → connect repo
3. Build command: `pip install requests`
4. Start command: `python server.py`
5. Set env var `PORT` = 10000

> Note: For cloud deploy, ChessKid credentials are sent over HTTPS to your Render server. Use HTTPS only.

